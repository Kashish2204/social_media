import React from "react";
import LeftSidebar from "./components/LeftSidebar.jsx";
import { Toaster, toast } from "sonner";
import ProfilePage from "./components/ProfilePage.jsx";
import { browser } from "globals";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";  
import MessagePage from "./components/MessagePage.jsx";
import SettingPage from "./components/SettingPage.jsx";
import Feed from "./components/Feed.jsx";
import  SearchPage from "./components/SearchPage.jsx";


function App() {

  return (
    <div className="flex">
      <LeftSidebar/>
      <div className="ml-64 w-full">
        {/* <ProfilePage/> */}
        {/* <MessagePage/> */}
        {/* <SettingPage/> */}
        { <Feed/> }



        {/* { <SearchPage/>} */}

        

      </div>
    </div>



    // <Router>
    //   <Routes>
    //     <Route path="/" element={<LeftSidebar/>}></Route>
    //     <Route path="/profile" element={<ProfilePage/>}></Route>
    //     <Route path="/message" element={<MessagePage/>}></Route>
    //     <Route path="/setting" element={<SettingPage/>}></Route>
    //     <Route path="/feed" element={<Feed/>}></Route>
    //     <Route path="/search" element={<SearchPage/>}></Route>

    //   </Routes>
    // </Router>
  );
  
  
};

export default App;





