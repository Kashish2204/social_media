import LeftSidebar from "./components/LeftSidebar.jsx";
import { Toaster, toast } from "sonner";
import ProfilePage from "./components/ProfilePage.jsx";
import { browser } from "globals";
import { BrowserRouter } from "react-router-dom";
import MessagePage from "./components/MessagePage.jsx";
import SettingPage from "./components/SettingPage.jsx";


function App() {

  return (
    <div className="flex">
      <LeftSidebar/>
      <div className="ml-64 w-full">
        {/* <ProfilePage/> */}
        {/* <MessagePage/> */}
        <SettingPage/>

      </div>
    </div>
  )
  
  
}

export default App;





